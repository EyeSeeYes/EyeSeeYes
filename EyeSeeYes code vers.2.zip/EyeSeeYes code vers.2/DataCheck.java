// The "DataCheck" class.
import java.awt.*;

/**
 * The class that performs the error check for times and phone numbers.
 * @author Angela Jeong
 * @version 3.0, Mar 22, 2014
 */
public class DataCheck
{
  
  /**
   * Errortraps the time.
   * @param time String
   */
  public static int checkTime (String time)
  {
   
  }